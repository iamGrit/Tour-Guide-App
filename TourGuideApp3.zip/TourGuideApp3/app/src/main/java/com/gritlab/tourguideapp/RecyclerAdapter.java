package com.gritlab.tourguideapp;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;
import java.util.Objects;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {


    private Context mContext;
    private List<Items> item;
    private Dialog mDialog;


    RecyclerAdapter(Context mContext, List<Items> mItems) {
        this.mContext = mContext;
        this.item = mItems;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.list_item, viewGroup, false);
        final MyViewHolder myViewHolder = new MyViewHolder(v);
        mDialog = new Dialog(mContext);
        mDialog.setContentView(R.layout.dialog);
        Objects.requireNonNull(mDialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                TextView dTitle = mDialog.findViewById(R.id.dialog_title);
                TextView dLocation = mDialog.findViewById(R.id.dialog_location);
                ImageView dImage = mDialog.findViewById(R.id.dialog_image);
                dImage.setImageResource(item.get(myViewHolder.getAdapterPosition()).getImageId());
                dLocation.setText(item.get(myViewHolder.getAdapterPosition()).getAddress());
                dTitle.setText(item.get(myViewHolder.getAdapterPosition()).getItemTitle());
                mDialog.show();
            }
        });
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.title.setText(item.get(i).getItemTitle());
        myViewHolder.location.setText(item.get(i).getAddress());
        if (item.get(i).hasImage()) {
            myViewHolder.imageView.setImageResource(item.get(i).getImageId());
        } else {
            myViewHolder.imageView.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return item.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView title;
        private TextView location;
        private ImageView imageView;


        MyViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.item_title_view);
            location = itemView.findViewById(R.id.item_location_view);
            imageView = itemView.findViewById(R.id.item_image_view);
        }
    }
}


