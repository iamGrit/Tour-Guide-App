package com.gritlab.tourguideapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class FragmentSalon extends Fragment {


    View v;
    private List<Items> items = new ArrayList<>();


    public FragmentSalon() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.salon_fragment, container, false);
        RecyclerAdapter mRecyclerAdapter = new RecyclerAdapter(getContext(), items);
        RecyclerView mRecyclerView = v.findViewById(R.id.salon_container);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mRecyclerAdapter);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        items.add(new Items(getString(R.string.awo_barbershop), getString(R.string.awo),R.drawable.ife ));
        items.add(new Items(getString(R.string.faj_barbershop), getString(R.string.faj),R.drawable.ife ));
        items.add(new Items(getString(R.string.new_market_salon), getString(R.string.new_market),R.drawable.ife ));
        items.add(new Items(getString(R.string.etf_barbershop), getString(R.string.etf),R.drawable.ife ));
        items.add(new Items(getString(R.string.sleek_and_silhouette), getString(R.string.new_buka),R.drawable.ife ));
        items.add(new Items(getString(R.string.awo_barbershop), getString(R.string.awo),R.drawable.ife ));
        items.add(new Items(getString(R.string.faj_barbershop), getString(R.string.faj),R.drawable.ife ));
        items.add(new Items(getString(R.string.new_market_salon), getString(R.string.new_market),R.drawable.ife ));
        items.add(new Items(getString(R.string.etf_barbershop), getString(R.string.etf),R.drawable.ife ));
        items.add(new Items(getString(R.string.sleek_and_silhouette), getString(R.string.new_buka),R.drawable.ife ));
        items.add(new Items(getString(R.string.awo_barbershop), getString(R.string.awo),R.drawable.ife ));
        items.add(new Items(getString(R.string.faj_barbershop), getString(R.string.faj),R.drawable.ife ));
        items.add(new Items(getString(R.string.new_market_salon), getString(R.string.new_market),R.drawable.ife ));
        items.add(new Items(getString(R.string.etf_barbershop), getString(R.string.etf),R.drawable.ife ));
        items.add(new Items(getString(R.string.sleek_and_silhouette), getString(R.string.new_buka),R.drawable.ife ));
    }
}

