package com.gritlab.tourguideapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class FragmentRestaurants extends Fragment {

    View v;
    private List<Items> items = new ArrayList<>();


    public FragmentRestaurants() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.restaurant_fragment, container, false);
        RecyclerAdapter mRecyclerAdapter = new RecyclerAdapter(getContext(), items);
        RecyclerView mRecyclerView = v.findViewById(R.id.restaurant_container);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mRecyclerAdapter);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        items.add(new Items(getString(R.string.awo_kitchen), getString(R.string.awo),R.drawable.ife ));
        items.add(new Items(getString(R.string.honeybee), getString(R.string.faj),R.drawable.ife ));
        items.add(new Items(getString(R.string.pg_kitchen), getString(R.string.pg_kich_location),R.drawable.ife ));
        items.add(new Items(getString(R.string.library_kitch), getString(R.string.h_o_lib),R.drawable.ife ));
        items.add(new Items(getString(R.string.awo_kitchen), getString(R.string.awo),R.drawable.ife ));
        items.add(new Items(getString(R.string.honeybee), getString(R.string.faj),R.drawable.ife ));
        items.add(new Items(getString(R.string.pg_kitchen), getString(R.string.pg_kich_location),R.drawable.ife ));
        items.add(new Items(getString(R.string.library_kitch), getString(R.string.h_o_lib),R.drawable.ife ));
        items.add(new Items(getString(R.string.awo_kitchen), getString(R.string.awo),R.drawable.ife ));
        items.add(new Items(getString(R.string.honeybee), getString(R.string.faj),R.drawable.ife ));
        items.add(new Items(getString(R.string.pg_kitchen), getString(R.string.pg_kich_location),R.drawable.ife ));
        items.add(new Items(getString(R.string.library_kitch), getString(R.string.h_o_lib),R.drawable.ife ));
    }
}
