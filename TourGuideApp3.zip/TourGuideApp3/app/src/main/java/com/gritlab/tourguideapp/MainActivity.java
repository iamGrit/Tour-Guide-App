package com.gritlab.tourguideapp;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabLayout tabLayout = findViewById(R.id.tablayout);
        ViewPager viewPager = findViewById(R.id.viewpager);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());


        adapter.addFragment(new FragmentHotspot(),"");
        adapter.addFragment(new FragmentRestaurants(),"");
        adapter.addFragment(new FragmentSalon(),"");
        adapter.addFragment(new FragmentViewingCenter(),"");

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        Objects.requireNonNull(tabLayout.getTabAt(0)).setIcon(R.drawable.ic_hotspot);
        Objects.requireNonNull(tabLayout.getTabAt(1)).setIcon(R.drawable.ic_restaurants);
        Objects.requireNonNull(tabLayout.getTabAt(2)).setIcon(R.drawable.ic_salon);
        Objects.requireNonNull(tabLayout.getTabAt(3)).setIcon(R.drawable.ic_viewing_center);

        ActionBar actionBar = getSupportActionBar();
        Objects.requireNonNull(actionBar).setElevation(0);
    }
}
