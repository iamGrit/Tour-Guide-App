package com.gritlab.tourguideapp;

public class Items {

    private int mImageId = NO_IMAGE_VIEW;
    private String mTitle;
    private String mAddress;
    private static final int NO_IMAGE_VIEW = -1;

    Items(String title, String address, int imageId) {
        mAddress = address;
        mImageId = imageId;
        mTitle = title;
    }

    public int getImageId() {
        return mImageId;
    }

    public String getItemTitle() {
        return mTitle;
    }

    public String getAddress() {
        return mAddress;
    }

    public boolean hasImage() {
        return (mImageId != NO_IMAGE_VIEW);
    }

}

