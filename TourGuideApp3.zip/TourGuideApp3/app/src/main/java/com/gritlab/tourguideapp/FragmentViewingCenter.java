package com.gritlab.tourguideapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class FragmentViewingCenter extends Fragment {

    View v;
    private List<Items> items = new ArrayList<>();

    public FragmentViewingCenter() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.viewing_center_fragment, container, false);
        RecyclerAdapter mRecyclerAdapter = new RecyclerAdapter(getContext(), items);
        RecyclerView mRecyclerView = v.findViewById(R.id.viewing_center_container);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mRecyclerAdapter);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        items.add(new Items(getString(R.string.awo_common_room), getString(R.string.awo), R.drawable.ife));
        items.add(new Items(getString(R.string.faj_common_room), getString(R.string.faj), R.drawable.ife));
        items.add(new Items(getString(R.string.new_market_bar), getString(R.string.new_market), R.drawable.ife));
        items.add(new Items(getString(R.string.etf_common_room), getString(R.string.etf), R.drawable.ife));
        items.add(new Items(getString(R.string.pg_common_room), getString(R.string.pg), R.drawable.ife));
        items.add(new Items(getString(R.string.awo_common_room), getString(R.string.awo), R.drawable.ife));
        items.add(new Items(getString(R.string.faj_common_room), getString(R.string.faj), R.drawable.ife));
        items.add(new Items(getString(R.string.new_market_bar), getString(R.string.new_market), R.drawable.ife));
        items.add(new Items(getString(R.string.etf_common_room), getString(R.string.etf), R.drawable.ife));
        items.add(new Items(getString(R.string.pg_common_room), getString(R.string.pg), R.drawable.ife));
        items.add(new Items(getString(R.string.awo_common_room), getString(R.string.awo), R.drawable.ife));
        items.add(new Items(getString(R.string.faj_common_room), getString(R.string.faj), R.drawable.ife));
        items.add(new Items(getString(R.string.new_market_bar), getString(R.string.new_market), R.drawable.ife));
        items.add(new Items(getString(R.string.etf_common_room), getString(R.string.etf), R.drawable.ife));
        items.add(new Items(getString(R.string.pg_common_room), getString(R.string.pg), R.drawable.ife));
    }
}
